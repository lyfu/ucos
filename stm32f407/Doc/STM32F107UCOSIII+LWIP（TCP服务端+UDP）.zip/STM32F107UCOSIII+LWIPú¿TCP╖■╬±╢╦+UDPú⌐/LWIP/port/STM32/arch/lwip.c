#include "tcpip.h"
#include "ethernetif.h"
#include "etharp.h"
#include "stm32_eth.h"
//#include "netconf.h"
//#include "server-netconn.h"
netif_t     main_net;
//static void LwIP_SendSem(void)
//{
// // sys_sem_signal(&lwip_eth_sem);
//  while(BSP_ETH_IsRxPktValid()) 
//   ethernetif_input(&main_net);
//}
/* MAC ADDRESS*/
#define MAC_ADDR0   02
#define MAC_ADDR1   00
#define MAC_ADDR2   00
#define MAC_ADDR3   00
#define MAC_ADDR4   00
#define MAC_ADDR5   00
 
/*Static IP ADDRESS*/
#define IP_ADDR0   192
#define IP_ADDR1   168
#define IP_ADDR2   1
#define IP_ADDR3   177
   
/*NETMASK*/
#define NETMASK_ADDR0   255
#define NETMASK_ADDR1   255
#define NETMASK_ADDR2   255
#define NETMASK_ADDR3   0

/*Gateway Address*/
#define GW_ADDR0   192
#define GW_ADDR1   168
#define GW_ADDR2   1
#define GW_ADDR3   1  

//#define ETHARP_HWADDR_LEN     6


void LwIP_Init(bool static_ip)
{
  u32 sn0;
	static uint8_t Addr[] = {0, 0x80, 0xE1,0,0,0 };
	struct ip_addr ipaddr;
  struct ip_addr netmask;
  struct ip_addr gw;
  tcpip_init(NULL, NULL);
  
  IP4_ADDR(&ipaddr, IP_ADDR0, IP_ADDR1, IP_ADDR2, IP_ADDR3);
  IP4_ADDR(&netmask, NETMASK_ADDR0, NETMASK_ADDR1 , NETMASK_ADDR2, NETMASK_ADDR3);
  IP4_ADDR(&gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
  
	sn0=*(vu32*)(0x1FFFF7E8);//��ȡSTM32��ΨһID��ǰ24λ��ΪMAC��ַ�����ֽ�
	Addr[3]=(sn0>>16)&0XFF;//�����ֽ���STM32��ΨһID
	Addr[4]=(sn0>>8)&0XFFF;;
	Addr[5]=sn0&0XFF; 
  MEMCPY(main_net.hwaddr,Addr,ETHARP_HWADDR_LEN);  //����MAC��ַ
	ETH_MACAddressConfig(ETH_MAC_Address0, Addr);  
  main_net.hwaddr_len=ETHARP_HWADDR_LEN;
  MEMCPY(main_net.name,"eth0",4);
#if LWIP_NETIF_HOSTNAME  
  main_net.hostname = GetHostName();
#endif
  netif_add(&main_net, &ipaddr, &netmask, &gw, NULL, &ethernetif_init, &tcpip_input);
  netif_set_default(&main_net);
	printf("\r\nͬ����IP��ַ:%ld,%ld,%ld,%ld \r\n",(ipaddr.addr>>0)&0xff,(ipaddr.addr>>8)&0xff,(ipaddr.addr>>16)&0xff,(ipaddr.addr>>24)&0xff);

 // BSP_ETH_IRQHandler = LwIP_SendSem;
  netif_set_up(&main_net);
}
void lwip_pkt_handle(void)
{
	ethernetif_input(&main_net);
}



/* ********************************************************************* */

#ifndef   __OS_CPU_BSP_
#define   __OS_CPU_BSP_

void BSP_Tick_Init (void);

#endif

#ifndef __ETH_DRIVER_
#define __ETH_DRIVER_

void init_ethernet(void);


#endif

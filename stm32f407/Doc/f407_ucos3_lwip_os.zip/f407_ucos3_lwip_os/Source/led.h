#ifndef __LED_DEBUG_H
#define __LED_DEBUG_H
extern void LedInit(void);
extern void LedPortDeInit(void);
extern void LedOn(void);
extern void LedOff(void);
extern void LedToggle(void);
#endif /* __LED_DEBUG_H */

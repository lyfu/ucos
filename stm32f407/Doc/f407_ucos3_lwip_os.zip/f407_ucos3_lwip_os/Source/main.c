#include "stm32f4xx.h"
#include "led.h"
#include "os.h"
#include "os_cpu_bsp.h"
#include "netconf.h"
#include "net_config.h"

#define  APP_TASK_START_STK_SIZE                    128
#define  APP_TASK_LED1_STK_SIZE                     128
#define  APP_TASK_NET_STK_SIZE                      512

#define  APP_TASK_START_PRIO                        2
#define  APP_TASK_LED1_PRIO                         3
#define  APP_TASK_NET_PRIO                          10

static OS_TCB AppTaskStartTCB;
static OS_TCB AppTaskLED1TCB;
static OS_TCB AppTaskNETTCB;

static CPU_STK AppTaskStartStk[APP_TASK_START_STK_SIZE];
static CPU_STK AppTaskLED1Stk[APP_TASK_LED1_STK_SIZE];
static CPU_STK AppTaskNETStk[APP_TASK_NET_STK_SIZE];

void Power_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;	    
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType  = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 ; 	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL; 
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_SetBits(GPIOB, GPIO_Pin_9);
}

void udpecho_init(void);
void tcpecho_init(void);
void AppTaskNET(void * pdata)
{
	/* Configure ethernet (GPIOs, clocks, MAC, DMA) */
	init_ethernet();
	/* Initilaize the LwIP stack */
	LwIP_Init();
	
	udpecho_init();
	tcpecho_init();
	
	/* Infinite loop */
  while (1)
  {
    /* check if any packet received */
    if (ETH_CheckFrameReceived())
    {
      /* process received ethernet packet */
      LwIP_Pkt_Handle();
    }
  }
}

void AppTaskLED1(void * pdata)
{
	OS_ERR err;
	
	while(1)
	{
		LedToggle();
		OSTimeDlyHMSM(0, 0, 0, 500, OS_OPT_TIME_HMSM_STRICT, &err);
	};
}

void AppTaskStart(void *p_arg)
{
	OS_ERR err;

	(void)p_arg;
	
	CPU_Init();
	Mem_Init();
	
	Power_Init();
	LedInit();
	BSP_Tick_Init();
	
	#if OS_CFG_STAT_TASK_EN > 0u
	OSStatTaskCPUUsageInit(&err);                               
	#endif

	CPU_IntDisMeasMaxCurReset();

	OSTaskCreate((OS_TCB     *)&AppTaskLED1TCB,
							 (CPU_CHAR   *)"App Task LED1",
							 (OS_TASK_PTR ) AppTaskLED1,
							 (void       *) 0,
							 (OS_PRIO     ) APP_TASK_LED1_PRIO,
							 (CPU_STK    *)&AppTaskLED1Stk[0],
							 (CPU_STK_SIZE) APP_TASK_LED1_STK_SIZE / 10,
							 (CPU_STK_SIZE) APP_TASK_LED1_STK_SIZE,
							 (OS_MSG_QTY  ) 5u,
							 (OS_TICK     ) 0u,
							 (void       *) 0,
							 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
							 (OS_ERR     *)&err);

	OSTaskCreate((OS_TCB     *)&AppTaskNETTCB,
							 (CPU_CHAR   *)"App Task NET",
							 (OS_TASK_PTR ) AppTaskNET,
							 (void       *) 0,
							 (OS_PRIO     ) APP_TASK_NET_PRIO,
							 (CPU_STK    *)&AppTaskNETStk[0],
							 (CPU_STK_SIZE) APP_TASK_NET_STK_SIZE / 10,
							 (CPU_STK_SIZE) APP_TASK_NET_STK_SIZE,
							 (OS_MSG_QTY  ) 5u,
							 (OS_TICK     ) 0u,
							 (void       *) 0,
							 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
							 (OS_ERR     *)&err);
							 
	OSTaskDel(&AppTaskStartTCB, &err);
}

int main(void)
{
	OS_ERR err;
	
	OSInit(&err);
	
	OSTaskCreate((OS_TCB     *)&AppTaskStartTCB,
							 (CPU_CHAR   *)"App Task Start",
							 (OS_TASK_PTR ) AppTaskStart,
							 (void       *) 0,
							 (OS_PRIO     ) APP_TASK_START_PRIO,
							 (CPU_STK    *)&AppTaskStartStk[0],
							 (CPU_STK_SIZE) APP_TASK_START_STK_SIZE / 10,
							 (CPU_STK_SIZE) APP_TASK_START_STK_SIZE,
							 (OS_MSG_QTY  ) 5u,
							 (OS_TICK     ) 0u,
							 (void       *) 0,
							 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
							 (OS_ERR     *)&err);
	
	OSStart(&err);
}
